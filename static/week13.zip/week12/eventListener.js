// get elements
const box = document.getElementById("box");
const output = document.getElementById("output");
const scroll = document.getElementById("scroll");

// event listeners
box.addEventListener("click", () => {
	output.innerHTML = "You clicked on the box!";
});

box.addEventListener("mouseenter", () => {
	box.style.background = "yellow";
});

box.addEventListener("mouseleave", () => {
	box.style.background = "#f0f0f0";
});

document.addEventListener("mousemove", (event) => {
	// console.log(`X: ${event.clientX}, Y: ${event.clientY}`);
});

scroll.addEventListener("scroll", () => {
	// console.log("Window Scroll:", window.scrollY);
	console.log("Element Scroll:", scroll.scrollTop);
});

window.addEventListener("keydown", (event) => {
	// console.log(event.key);
});
