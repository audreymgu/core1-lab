function startTime() {
	// get time and date
	const today = new Date();

	// extract hours, minutes, and seconds
	let h = today.getHours();
	let m = today.getMinutes();
	let s = today.getSeconds();

	// format minutes and seconds
	m = formatTime(m);
	s = formatTime(s);

	// replace inner HTML of our elements
	document.getElementById("hour").innerHTML = h;
	document.getElementById("min").innerHTML = m;
	document.getElementById("sec").innerHTML = s;

	// set update interval
	setTimeout(startTime, 1000);
}

function formatTime(i) {
	// add zero in front of numbers less 10
	if (i < 10) {
		i = "0" + i;
	}

	return i;
}
