// logging
console.log("Hello World");

// static declaration
// const x = 5;
// console.log(x);

// dynamic declaration
// let y = 3;
// console.log(y);

// conditional logic
// if (y == 7) {
// 	console.log("Y is equal to 7!");
// }

// interact with HTML!
// document.getElementById().innerHTML = 'Boop!';
// document.getElementById().style.color = 'red';
